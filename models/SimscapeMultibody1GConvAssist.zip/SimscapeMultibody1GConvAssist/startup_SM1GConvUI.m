% Copyright 2014-2017 The MathWorks, Inc.

addpath([pwd filesep 'Functions']);
addpath([pwd filesep 'Functions' filesep 'Help']);
SM1G_Conversion_Assistant_UI

